// ===== STAR SKY BACKGROUND =====
class StarSky {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.stars = [];
        this._fc = 0;
        this._dpr = Math.min(window.devicePixelRatio || 1, 2);
        this._isLight = document.body && document.body.classList.contains('light');
        this._w = 0;
        this._h = 0;
        this.resize();
        window.addEventListener('resize', () => this.resize());
        this.draw();
    }

    resize() {
        const dpr = this._dpr;
        this._w = window.innerWidth;
        this._h = window.innerHeight;
        this.canvas.width = this._w * dpr;
        this.canvas.height = this._h * dpr;
        this.canvas.style.width = this._w + 'px';
        this.canvas.style.height = this._h + 'px';
        this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        const n = Math.min(200, Math.floor(this._w * this._h / 6000));
        this.stars = [];
        for (let i = 0; i < n; i++) {
            this.stars.push({
                x: Math.random() * this._w,
                y: Math.random() * this._h,
                r: Math.random() * 1.2 + 0.2,
                o: Math.random() * 0.5 + 0.12,
                dx: (Math.random() - 0.5) * 0.18,
                dy: (Math.random() - 0.5) * 0.18,
                phase: Math.random() * Math.PI * 2
            });
        }
    }

    draw() {
        const ctx = this.ctx;
        const w = this._w, h = this._h;
        ctx.clearRect(0, 0, w, h);

        // Light theme: soft pastel dots, not dark/black
        const rgb = this._isLight ? '160,150,220' : '255,255,255';
        const alphaMultiplier = this._isLight ? 0.35 : 1;

        for (let i = 0; i < this.stars.length; i++) {
            const s = this.stars[i];
            s.x += s.dx;
            s.y += s.dy;
            if (s.x < 0 || s.x > w) s.dx *= -1;
            if (s.y < 0 || s.y > h) s.dy *= -1;

            s.phase += 0.006;
            const a = s.o * (0.85 + 0.15 * Math.sin(s.phase)) * alphaMultiplier;

            ctx.beginPath();
            ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(' + rgb + ',' + a + ')';
            ctx.fill();
        }

        if (++this._fc % 90 === 0) {
            this._isLight = document.body && document.body.classList.contains('light');
        }
        requestAnimationFrame(() => this.draw());
    }
}

// ===== SCROLL ANIMATIONS =====
class ScrollAnimator {
    constructor() {
        this.elements = document.querySelectorAll('.animate-on-scroll');
        this.init();
    }

    init() {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                    }
                });
            },
            { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
        );

        this.elements.forEach((el) => observer.observe(el));
    }
}

// ===== COUNTER ANIMATION =====
class CounterAnimator {
    constructor() {
        this.counters = document.querySelectorAll('[data-count]');
        this.animated = new Set();
        this.init();
    }

    init() {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting && !this.animated.has(entry.target)) {
                        this.animated.add(entry.target);
                        this.animateCounter(entry.target);
                    }
                });
            },
            { threshold: 0.5 }
        );

        this.counters.forEach((counter) => observer.observe(counter));
    }

    animateCounter(el) {
        const target = parseInt(el.getAttribute('data-count'));
        const duration = 2000;
        const startTime = performance.now();

        const step = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 4); // easeOutQuart
            const current = Math.floor(eased * target);

            el.textContent = current.toLocaleString('ru-RU');

            if (progress < 1) {
                requestAnimationFrame(step);
            } else {
                el.textContent = target.toLocaleString('ru-RU');
            }
        };

        requestAnimationFrame(step);
    }
}

// ===== NAVBAR =====
class Navbar {
    constructor() {
        this.navbar = document.getElementById('navbar');
        this.toggle = document.getElementById('navToggle');
        this.links = document.getElementById('navLinks');
        this.overlay = document.getElementById('navOverlay');
        if (!this.navbar || !this.toggle || !this.links) return;
        this.init();
    }

    init() {
        // Scroll effect
        window.addEventListener('scroll', () => {
            this.navbar.classList.toggle('scrolled', window.scrollY > 50);
        });

        // Mobile toggle
        this.toggle.addEventListener('click', () => {
            this.links.classList.toggle('active');
            this.toggle.classList.toggle('active');
            if (this.overlay) this.overlay.classList.toggle('active');
            document.body.style.overflow = this.links.classList.contains('active') ? 'hidden' : '';
        });

        // Close on link click
        this.links.querySelectorAll('.nav-link').forEach((link) => {
            link.addEventListener('click', () => {
                this.links.classList.remove('active');
                this.toggle.classList.remove('active');
                if (this.overlay) this.overlay.classList.remove('active');
                document.body.style.overflow = '';
            });
        });

        // Close on overlay click
        if (this.overlay) {
            this.overlay.addEventListener('click', () => {
                this.links.classList.remove('active');
                this.toggle.classList.remove('active');
                this.overlay.classList.remove('active');
                document.body.style.overflow = '';
            });
        }

        // Active link on scroll
        const sections = document.querySelectorAll('section[id]');
        window.addEventListener('scroll', () => {
            const scrollY = window.scrollY + 100;
            sections.forEach((section) => {
                const top = section.offsetTop;
                const height = section.offsetHeight;
                const id = section.getAttribute('id');
                const link = this.links.querySelector(`a[href="#${id}"]`);
                if (link) {
                    if (scrollY >= top && scrollY < top + height) {
                        link.style.color = '#e8e8f0';
                    } else {
                        link.style.color = '';
                    }
                }
            });
        });
    }
}

// ===== SMOOTH SCROLL =====
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});

// Contact form handled by initContactForm() in DOMContentLoaded

// ===== MAGNETIC BUTTONS =====
document.querySelectorAll('.btn-primary').forEach((btn) => {
    btn.addEventListener('mousemove', function (e) {
        const rect = this.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;
        this.style.transform = `translate(${x * 0.15}px, ${y * 0.15}px)`;
    });

    btn.addEventListener('mouseleave', function () {
        this.style.transform = '';
    });
});

// ===== TILT EFFECT ON CARDS =====
document.querySelectorAll('.service-card, .about-card').forEach((card) => {
    card.addEventListener('mousemove', function (e) {
        const rect = this.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width - 0.5;
        const y = (e.clientY - rect.top) / rect.height - 0.5;
        this.style.transform = `perspective(800px) rotateY(${x * 6}deg) rotateX(${-y * 6}deg) translateY(-4px)`;
    });
    card.addEventListener('mouseleave', function () {
        this.style.transform = '';
    });
});

// ===== PARALLAX ON HERO ORBS =====
window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;
    document.querySelectorAll('.hero-orb').forEach((orb, i) => {
        const speed = (i + 1) * 0.15;
        orb.style.transform = `translateY(${scrollY * speed}px)`;
    });
});

// ===== LANGUAGE (auto IP + manual toggle) =====
class LanguageManager {
    constructor() {
        this.lang = localStorage.getItem('tp_lang') || null;
        this.btn = document.getElementById('langToggle');
        this.label = this.btn ? this.btn.querySelector('.lang-label') : null;
        if (this.lang) { this.apply(); } else { this.lang = 'ru'; this.autoDetect(); }
        if (this.btn) this.btn.addEventListener('click', () => { this.lang = this.lang === 'ru' ? 'en' : 'ru'; localStorage.setItem('tp_lang', this.lang); this.apply(); });
        this.updateLabel();
    }
    async autoDetect() {
        try { const r = await fetch('https://ipapi.co/json/', {signal:AbortSignal.timeout(3000)}); const d = await r.json(); if (d.country_code && d.country_code !== 'RU') { this.lang = 'en'; this.apply(); } } catch(e) {}
    }
    apply() {
        document.querySelectorAll('[data-ru][data-en]').forEach(el => { const t = el.getAttribute('data-'+this.lang); if(t){if(el.childElementCount===0){el.textContent=t}else{const n=Array.from(el.childNodes).find(n=>n.nodeType===3&&n.textContent.trim());if(n)n.textContent=t}} });
        this.updateLabel();
    }
    updateLabel() { if (this.label) this.label.textContent = this.lang === 'ru' ? 'RU' : 'EN'; }
}

// ===== THEME (auto browser + manual toggle) =====
class ThemeManager {
    constructor() {
        this.btn = document.getElementById('themeToggle');
        const saved = localStorage.getItem('tp_theme');
        if (saved) { this.set(saved); } else { const mq = window.matchMedia('(prefers-color-scheme: light)'); this.set(mq.matches ? 'light' : 'dark'); }
        if (this.btn) this.btn.addEventListener('click', () => { const next = document.body.classList.contains('light') ? 'dark' : 'light'; localStorage.setItem('tp_theme', next); this.set(next); });
    }
    set(theme) {
        document.body.classList.toggle('light', theme === 'light');
        if (this.btn) { const sun = this.btn.querySelector('.icon-sun'); const moon = this.btn.querySelector('.icon-moon'); if(sun&&moon){sun.style.display=theme==='light'?'none':'block';moon.style.display=theme==='light'?'block':'none';} }
    }
}

// ===== ANTI-DOWNLOAD PROTECTION =====
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', e => {
    if (e.ctrlKey && (e.key === 's' || e.key === 'S' || e.key === 'u' || e.key === 'U')) e.preventDefault();
    if (e.ctrlKey && e.shiftKey && (e.key === 'i' || e.key === 'I' || e.key === 'j' || e.key === 'J')) e.preventDefault();
});

// ===== CONTACT FORM =====
function initContactForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        const btn = form.querySelector('button[type="submit"]');
        const origHTML = btn.innerHTML;
        btn.disabled = true;
        const _l = localStorage.getItem('tp_lang') || 'ru';
        btn.innerHTML = '<span>' + (_l==='en'?'Sending...':'Отправка...') + '</span>';
        try {
            const res = await fetch('/api/v1/contact', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: form.querySelector('#name').value,
                    email: form.querySelector('#email').value,
                    message: form.querySelector('#message').value
                })
            });
            if (res.ok) {
                btn.innerHTML = '<span>✓ ' + (_l==='en'?'Sent':'Отправлено') + '</span>';
                form.reset();
                setTimeout(() => { btn.innerHTML = origHTML; btn.disabled = false; }, 3000);
            } else {
                btn.innerHTML = '<span>' + (_l==='en'?'Error':'Ошибка') + '</span>';
                setTimeout(() => { btn.innerHTML = origHTML; btn.disabled = false; }, 2000);
            }
        } catch(err) {
            window.location.href = 'mailto:info@tokenpay.space?subject=' + encodeURIComponent(_l==='en'?'Feedback':'Обратная связь') + '&body=' + encodeURIComponent(form.querySelector('#message').value);
            btn.innerHTML = origHTML; btn.disabled = false;
        }
    });
}

// ===== AUTH NAV CHECK =====
function _escHtml(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function updateNavAuth() {
    const token = localStorage.getItem('tpid_token') || sessionStorage.getItem('tpid_token');
    const refreshTok = localStorage.getItem('tpid_refresh') || sessionStorage.getItem('tpid_refresh');
    const user = (() => { try { return JSON.parse(localStorage.getItem('tpid_user') || sessionStorage.getItem('tpid_user') || 'null'); } catch(e) { return null; } })();
    if (!token && !refreshTok) return;

    const _lang = localStorage.getItem('tp_lang') || (navigator.language && navigator.language.startsWith('en') ? 'en' : 'ru');
    const label = _lang === 'en' ? 'Dashboard' : 'Личный кабинет';

    // Desktop .nav-auth
    const navAuth = document.querySelector('.nav-auth');
    if (navAuth) {
        navAuth.innerHTML = `<a href="/dashboard" class="nav-btn nav-btn-white tpid-brand-btn" style="display:flex;align-items:center;gap:7px;background:linear-gradient(135deg,#6c63ff,#4ecdc4);border:none;color:#fff;padding:8px 18px;border-radius:10px;font-weight:600;font-size:.82rem;transition:all .2s;box-shadow:0 2px 12px rgba(108,99,255,.25)">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            <span>${label}</span>
        </a>`;
    }

    // Mobile .nav-mobile-auth
    const mobileAuth = document.querySelector('.nav-mobile-auth');
    if (mobileAuth) {
        mobileAuth.innerHTML = `<a href="/dashboard" class="btn btn-primary tpid-brand-btn" style="width:100%;justify-content:center;gap:8px;background:linear-gradient(135deg,#6c63ff,#4ecdc4);border:none">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            <span>${label}</span>
        </a>`;
    }

    // Validate token silently; if invalid try refresh
    fetch('/api/v1/auth/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token }) })
        .then(r => r.json()).then(d => {
            if (d.valid) return;
            if (refreshTok) {
                fetch('/api/v1/auth/refresh', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refresh_token: refreshTok }) })
                    .then(r => r.json()).then(data => {
                        if (data.accessToken) {
                            const store = sessionStorage.getItem('tpid_refresh') ? sessionStorage : localStorage;
                            store.setItem('tpid_token', data.accessToken);
                            if (data.refreshToken) store.setItem('tpid_refresh', data.refreshToken);
                        } else {
                            // Both invalid — clear and show login buttons
                            ['tpid_token','tpid_refresh','tpid_user','tp_token'].forEach(k => { localStorage.removeItem(k); sessionStorage.removeItem(k); });
                            if (navAuth) navAuth.innerHTML = `<a href="/login" class="nav-btn nav-btn-white tpid-brand-btn" style="display:flex;align-items:center;gap:7px;background:linear-gradient(135deg,#6c63ff,#4ecdc4);border:none;color:#fff;padding:8px 18px;border-radius:10px;font-weight:600;font-size:.82rem;transition:all .2s;box-shadow:0 2px 12px rgba(108,99,255,.25)"><img src='/tokenpay-id-light.png' alt='' style='height:15px;width:auto;opacity:.9'><span>TOKEN PAY ID</span></a>`;
                            if (mobileAuth) mobileAuth.innerHTML = `<a href="/login" class="btn btn-primary tpid-brand-btn" style="width:100%;justify-content:center;gap:8px;background:linear-gradient(135deg,#6c63ff,#4ecdc4);border:none"><img src='/tokenpay-id-light.png' alt='' style='height:16px;width:auto;opacity:.9'><span>TOKEN PAY ID</span></a>`;
                        }
                    }).catch(() => {});
            }
        }).catch(() => {});
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('particles');
    if (canvas) new StarSky(canvas);

    new ScrollAnimator();
    new CounterAnimator();
    new Navbar();
    new LanguageManager();
    new ThemeManager();
    initContactForm();
    updateNavAuth();
});

// ===== CSS for spin animation (injected) =====
const style = document.createElement('style');
style.textContent = `
    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
`;
document.head.appendChild(style);

// ===== GLOBAL TOAST NOTIFICATION SYSTEM =====
window.tpToast = (function() {
    let container = null;
    function getContainer() {
        if (!container || !document.body.contains(container)) {
            container = document.createElement('div');
            container.className = 'tp-toast-container';
            document.body.appendChild(container);
        }
        return container;
    }
    const icons = {
        success: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg>',
        error:   '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
        info:    '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
        warn:    '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>'
    };
    function show(msg, type, duration) {
        type = type || 'info';
        duration = duration == null ? 3500 : duration;
        const c = getContainer();
        const t = document.createElement('div');
        t.className = 'tp-toast tp-toast-' + type;
        t.innerHTML =
            '<span class="tp-toast-icon">' + (icons[type] || icons.info) + '</span>' +
            '<span class="tp-toast-text">' + msg + '</span>' +
            '<button class="tp-toast-close" onclick="this.parentNode.remove()">✕</button>';
        c.appendChild(t);
        if (duration > 0) {
            setTimeout(() => {
                t.classList.add('toast-hide');
                setTimeout(() => t.remove(), 350);
            }, duration);
        }
        return t;
    }
    return {
        success: (m, d) => show(m, 'success', d),
        error:   (m, d) => show(m, 'error', d),
        info:    (m, d) => show(m, 'info', d),
        warn:    (m, d) => show(m, 'warn', d),
        show
    };
})();

// ===== BUTTON RIPPLE EFFECT =====
document.addEventListener('click', function(e) {
    const btn = e.target.closest('.auth-btn,.tp-btn,.nav-btn,.qa-btn,.tp-ripple,.dash-save-btn');
    if (!btn) return;
    const rect = btn.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 2;
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;
    const ripple = document.createElement('span');
    ripple.className = 'tp-ripple-effect';
    ripple.style.cssText = 'width:' + size + 'px;height:' + size + 'px;left:' + x + 'px;top:' + y + 'px';
    if (!btn.style.position || btn.style.position === 'static') btn.style.position = 'relative';
    btn.style.overflow = 'hidden';
    btn.appendChild(ripple);
    ripple.addEventListener('animationend', () => ripple.remove());
});
