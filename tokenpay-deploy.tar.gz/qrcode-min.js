/**
 * Minimal QR Code Generator — no dependencies
 * Supports alphanumeric & byte mode, Version 1-10, ECC Level L/M
 * Returns { modules: boolean[][] } for canvas rendering
 */
var QRCode=(function(){
'use strict';
// GF(256) arithmetic
var EXP=new Uint8Array(512),LOG=new Uint8Array(256);
(function(){var v=1;for(var i=0;i<255;i++){EXP[i]=v;LOG[v]=i;v<<=1;if(v>=256)v^=0x11d;}for(var i=255;i<512;i++)EXP[i]=EXP[i-255];})();
function gfMul(a,b){return a===0||b===0?0:EXP[LOG[a]+LOG[b]];}

function polyMul(a,b){
    var r=new Uint8Array(a.length+b.length-1);
    for(var i=0;i<a.length;i++)for(var j=0;j<b.length;j++)r[i+j]^=gfMul(a[i],b[j]);
    return r;
}

function genPoly(n){
    var p=new Uint8Array([1]);
    for(var i=0;i<n;i++)p=polyMul(p,new Uint8Array([1,EXP[i]]));
    return p;
}

function eccEncode(data,eccLen){
    var gen=genPoly(eccLen);
    var msg=new Uint8Array(data.length+eccLen);
    msg.set(data);
    for(var i=0;i<data.length;i++){
        var coef=msg[i];
        if(coef!==0)for(var j=0;j<gen.length;j++)msg[i+j]^=gfMul(gen[j],coef);
    }
    return msg.slice(data.length);
}

// Version info
var VERSIONS=[
    null,
    {total:26,data:19,ecc:7,ecBlocks:[1]},    // V1-L
    {total:44,data:34,ecc:10,ecBlocks:[1]},    // V2-L
    {total:70,data:55,ecc:15,ecBlocks:[1]},    // V3-L
    {total:100,data:80,ecc:20,ecBlocks:[1]},   // V4-L
    {total:134,data:108,ecc:26,ecBlocks:[1]},  // V5-L
    {total:172,data:136,ecc:18,ecBlocks:[2]},  // V6-L
    {total:196,data:156,ecc:20,ecBlocks:[2]},  // V7-L
    {total:242,data:192,ecc:24,ecBlocks:[2]},  // V8-L
    {total:292,data:232,ecc:30,ecBlocks:[2]},  // V9-L
    {total:346,data:274,ecc:18,ecBlocks:[2,2]},// V10-L
];

// Alignment pattern positions
var ALIGN_POS=[null,null,[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50]];

function getVersion(dataLen){
    for(var v=1;v<=10;v++){
        if(VERSIONS[v].data>=dataLen+3)return v; // +3 for mode+length+terminator overhead
    }
    return 10;
}

function encodeData(text){
    // Byte mode encoding
    var bytes=[];
    for(var i=0;i<text.length;i++){
        var c=text.charCodeAt(i);
        if(c<128)bytes.push(c);
        else if(c<2048){bytes.push(192|(c>>6));bytes.push(128|(c&63));}
        else{bytes.push(224|(c>>12));bytes.push(128|((c>>6)&63));bytes.push(128|(c&63));}
    }

    // Find version
    var ver=1;
    for(var v=1;v<=10;v++){
        var cap=VERSIONS[v].data;
        // Mode(4)+Count(8 for v1-9, 16 for v10+)+data+terminator
        var countBits=v<=9?8:16;
        var needed=Math.ceil((4+countBits+bytes.length*8)/8);
        if(needed<=cap){ver=v;break;}
        if(v===10)ver=10;
    }
    var info=VERSIONS[ver];
    var dataCap=info.data;

    // Build bit stream
    var bits=[];
    function pushBits(val,len){for(var i=len-1;i>=0;i--)bits.push((val>>i)&1);}

    pushBits(0b0100,4); // Byte mode
    pushBits(bytes.length,ver<=9?8:16);
    for(var i=0;i<bytes.length;i++)pushBits(bytes[i],8);

    // Terminator
    var maxBits=dataCap*8;
    var termLen=Math.min(4,maxBits-bits.length);
    for(var i=0;i<termLen;i++)bits.push(0);

    // Pad to byte boundary
    while(bits.length%8!==0)bits.push(0);

    // Pad bytes
    var padBytes=[0xEC,0x11];
    var pi=0;
    while(bits.length<maxBits){
        pushBits(padBytes[pi%2],8);
        pi++;
    }

    // Convert to bytes
    var dataBytes=new Uint8Array(dataCap);
    for(var i=0;i<dataCap;i++){
        var b=0;
        for(var j=0;j<8;j++)b=(b<<1)|bits[i*8+j];
        dataBytes[i]=b;
    }

    // ECC
    var eccBytes=eccEncode(dataBytes,info.ecc);

    return {ver:ver,data:dataBytes,ecc:eccBytes,info:info};
}

function createMatrix(ver){
    var size=ver*4+17;
    var matrix=[];
    var reserved=[];
    for(var i=0;i<size;i++){
        matrix.push(new Array(size).fill(0));
        reserved.push(new Array(size).fill(false));
    }
    return {matrix:matrix,reserved:reserved,size:size};
}

function setModule(m,r,c,val){
    if(r>=0&&r<m.size&&c>=0&&c<m.size){m.matrix[r][c]=val?1:0;m.reserved[r][c]=true;}
}

function addFinderPattern(m,row,col){
    for(var r=-1;r<=7;r++)for(var c=-1;c<=7;c++){
        var rr=row+r,cc=col+c;
        if(rr<0||rr>=m.size||cc<0||cc>=m.size)continue;
        var inOuter=(r>=0&&r<=6&&(c===0||c===6))||(c>=0&&c<=6&&(r===0||r===6));
        var inInner=(r>=2&&r<=4&&c>=2&&c<=4);
        setModule(m,rr,cc,inOuter||inInner);
    }
}

function addAlignmentPattern(m,row,col){
    for(var r=-2;r<=2;r++)for(var c=-2;c<=2;c++){
        var val=Math.abs(r)===2||Math.abs(c)===2||(r===0&&c===0);
        setModule(m,row+r,col+c,val);
    }
}

function addTimingPatterns(m){
    for(var i=8;i<m.size-8;i++){
        setModule(m,6,i,i%2===0);
        setModule(m,i,6,i%2===0);
    }
}

function addFormatInfo(m,mask){
    // Format info for ECC Level L (01) and mask pattern
    var data=(1<<3)|mask; // ECC L = 01
    var bits=data;
    // BCH(15,5) encoding
    for(var i=4;i>=0;i--){
        if(bits&(1<<(i+10)))bits^=(0x537<<i);
    }
    // Wait, let me do this properly
    var FORMAT_BITS=[
        0x77C4,0x72F3,0x7DAA,0x789D,0x662F,0x6318,0x6C41,0x6976,
        0x5412,0x5125,0x5E7C,0x5B4B,0x45F9,0x40CE,0x4F97,0x4AA0,
        0x355F,0x3068,0x3F31,0x3A06,0x24B4,0x2183,0x2EDA,0x2BED,
        0x1689,0x13BE,0x1CE7,0x19D0,0x0762,0x0255,0x0D0C,0x083B
    ];
    var idx=(1<<3)|mask; // ECC L=01 -> 01xxx
    var fmt=FORMAT_BITS[idx];

    // Place format bits
    // Around top-left finder
    var positions=[
        [0,8],[1,8],[2,8],[3,8],[4,8],[5,8],[7,8],[8,8],
        [8,7],[8,5],[8,4],[8,3],[8,2],[8,1],[8,0]
    ];
    for(var i=0;i<15;i++){
        var bit=(fmt>>(14-i))&1;
        setModule(m,positions[i][0],positions[i][1],bit);
    }
    // Around top-right and bottom-left finders
    for(var i=0;i<8;i++){
        var bit=(fmt>>(14-i))&1;
        setModule(m,8,m.size-1-i,bit);
    }
    for(var i=8;i<15;i++){
        var bit=(fmt>>(14-i))&1;
        setModule(m,m.size-1-(14-i),8,bit);
    }
    // Dark module
    setModule(m,m.size-8,8,1);
}

function placeData(m,dataBytes,eccBytes){
    var allBits=[];
    for(var i=0;i<dataBytes.length;i++)
        for(var j=7;j>=0;j--)allBits.push((dataBytes[i]>>j)&1);
    for(var i=0;i<eccBytes.length;i++)
        for(var j=7;j>=0;j--)allBits.push((eccBytes[i]>>j)&1);

    var bitIdx=0;
    var upward=true;
    for(var right=m.size-1;right>=1;right-=2){
        if(right===6)right=5; // Skip timing column
        for(var vert=0;vert<m.size;vert++){
            var row=upward?m.size-1-vert:vert;
            for(var dx=0;dx<=1;dx++){
                var col=right-dx;
                if(col<0||col>=m.size)continue;
                if(m.reserved[row][col])continue;
                if(bitIdx<allBits.length){
                    m.matrix[row][col]=allBits[bitIdx];
                    bitIdx++;
                }
            }
        }
        upward=!upward;
    }
}

function applyMask(m,maskNum){
    var maskFns=[
        function(r,c){return(r+c)%2===0;},
        function(r,c){return r%2===0;},
        function(r,c){return c%3===0;},
        function(r,c){return(r+c)%3===0;},
        function(r,c){return(Math.floor(r/2)+Math.floor(c/3))%2===0;},
        function(r,c){return(r*c)%2+(r*c)%3===0;},
        function(r,c){return((r*c)%2+(r*c)%3)%2===0;},
        function(r,c){return((r+c)%2+(r*c)%3)%2===0;}
    ];
    var fn=maskFns[maskNum];
    for(var r=0;r<m.size;r++)
        for(var c=0;c<m.size;c++)
            if(!m.reserved[r][c]&&fn(r,c))m.matrix[r][c]^=1;
}

function scoreMask(m){
    var s=m.size,mat=m.matrix,score=0;
    // Rule 1: runs of same color
    for(var r=0;r<s;r++){
        var run=1;
        for(var c=1;c<s;c++){
            if(mat[r][c]===mat[r][c-1])run++;
            else{if(run>=5)score+=run-2;run=1;}
        }
        if(run>=5)score+=run-2;
    }
    for(var c=0;c<s;c++){
        var run=1;
        for(var r=1;r<s;r++){
            if(mat[r][c]===mat[r-1][c])run++;
            else{if(run>=5)score+=run-2;run=1;}
        }
        if(run>=5)score+=run-2;
    }
    // Rule 2: 2x2 blocks
    for(var r=0;r<s-1;r++)for(var c=0;c<s-1;c++){
        var v=mat[r][c];
        if(v===mat[r][c+1]&&v===mat[r+1][c]&&v===mat[r+1][c+1])score+=3;
    }
    return score;
}

function generate(text){
    var enc=encodeData(text);
    var bestMatrix=null,bestScore=Infinity;

    for(var mask=0;mask<8;mask++){
        var m=createMatrix(enc.ver);

        // Finder patterns
        addFinderPattern(m,0,0);
        addFinderPattern(m,0,m.size-7);
        addFinderPattern(m,m.size-7,0);

        // Alignment patterns
        var ap=ALIGN_POS[enc.ver];
        if(ap){
            for(var i=0;i<ap.length;i++)for(var j=0;j<ap.length;j++){
                // Skip if overlapping finder
                if(i===0&&j===0)continue;
                if(i===0&&j===ap.length-1)continue;
                if(i===ap.length-1&&j===0)continue;
                addAlignmentPattern(m,ap[i],ap[j]);
            }
        }

        addTimingPatterns(m);
        addFormatInfo(m,mask);
        placeData(m,enc.data,enc.ecc);
        applyMask(m,mask);

        var sc=scoreMask(m);
        if(sc<bestScore){bestScore=sc;bestMatrix=m;}
    }

    // Convert to boolean modules
    var modules=[];
    for(var r=0;r<bestMatrix.size;r++){
        var row=[];
        for(var c=0;c<bestMatrix.size;c++)row.push(bestMatrix.matrix[r][c]===1);
        modules.push(row);
    }
    return {modules:modules,size:bestMatrix.size,version:enc.ver};
    }

    return {generate:generate};
})();
