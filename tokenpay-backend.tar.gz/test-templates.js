#!/usr/bin/env node
/**
 * TOKEN PAY ID — Email Template Unit Tests
 * Run: node test-templates.js
 */

const { templates } = require('./email-service');

const OK = '\x1b[92m✓\x1b[0m';
const FAIL = '\x1b[91m✗\x1b[0m';
let passed = 0, failed = 0;

function test(name, condition, detail = '') {
    if (condition) { passed++; console.log(`  ${OK} ${name}${detail ? '  (' + detail + ')' : ''}`); }
    else { failed++; console.log(`  ${FAIL} ${name}${detail ? '  (' + detail + ')' : ''}`); }
}

function section(title) { console.log(`\n\x1b[1m=== ${title} ===\x1b[0m`); }

// ===== VERIFICATION CODE TEMPLATE =====
section('Verification Code Template');
{
    const tpl = templates.verificationCode('Иван', '123456', 10, 'ru');
    test('Returns html and text', !!tpl.html && !!tpl.text);
    test('HTML contains Comfortaa font import', tpl.html.includes('Comfortaa'));
    test('HTML contains code value', tpl.html.includes('123456'));
    test('HTML contains user name', tpl.html.includes('Иван'));
    test('No stripe divider under logo', !tpl.html.includes('height:2px;background:rgba(255,255,255'));
    test('Has TOKEN PAY ID branding', tpl.html.includes('TOKEN PAY'));
    test('Has preheader text', tpl.html.includes('zwnj'));
    test('Plain text contains code', tpl.text.includes('123456'));

    const tplEn = templates.verificationCode('John', '654321', 5, 'en');
    test('English template works', tplEn.html.includes('John') && tplEn.html.includes('654321'));
    test('English has Verification Code label', tplEn.html.includes('Verification Code'));
    test('English has valid for text', tplEn.text.includes('5 minutes'));
}

// ===== LOGIN NOTIFICATION TEMPLATE =====
section('Login Notification Template');
{
    const tpl = templates.loginNotification('Test User', '192.168.1.1', 'Chrome (desktop)', '2025-03-27 10:00', 'ru');
    test('Has IP address', tpl.html.includes('192.168.1.1'));
    test('Has device info', tpl.html.includes('Chrome (desktop)'));
    test('Has Comfortaa font', tpl.html.includes('Comfortaa'));
    test('No logo stripe', !tpl.html.includes('height:2px;background:rgba(255,255,255'));
}

// ===== WELCOME TEMPLATE =====
section('Welcome Template');
{
    const tpl = templates.welcome('Алексей', 'ru');
    test('Has user name', tpl.html.includes('Алексей'));
    test('Has Comfortaa', tpl.html.includes('Comfortaa'));

    const tplEn = templates.welcome('Alice', 'en');
    test('English welcome works', tplEn.html.includes('Alice'));
}

// ===== PASSWORD RESET TEMPLATE =====
section('Password Reset Template');
{
    const tpl = templates.passwordReset('User', '999999', 15, 'ru');
    test('Has reset code', tpl.html.includes('999999'));
    test('Has Comfortaa', tpl.html.includes('Comfortaa'));
}

// ===== OAUTH APPROVAL TEMPLATE =====
section('OAuth Approval Template');
{
    const tpl = templates.oauthApproval('Test', 'MyApp', 'profile email', 'ru');
    test('Has app name', tpl.html.includes('MyApp'));
    test('Has scope', tpl.html.includes('profile email'));
    test('Has Comfortaa', tpl.html.includes('Comfortaa'));
}

// ===== API KEY CREATED TEMPLATE =====
section('API Key Created Template');
{
    const tpl = templates.apiKeyCreated('Dev', 'My Key', 'pk_test123', 'ru');
    test('Has public key', tpl.html.includes('pk_test123'));
    test('Has key name', tpl.html.includes('My Key'));
    test('Has Comfortaa', tpl.html.includes('Comfortaa'));
}

// ===== ENTERPRISE APPROVED/REJECTED =====
section('Enterprise Templates');
{
    const approved = templates.enterpriseApproved('Boss', 'Acme Inc', 'ru');
    test('Approved has company name', approved.html.includes('Acme Inc'));
    test('Approved has Comfortaa', approved.html.includes('Comfortaa'));

    const rejected = templates.enterpriseRejected('Boss', 'Acme Inc', 'Not enough documents', 'en');
    test('Rejected has reason', rejected.html.includes('Not enough documents'));
    test('Rejected English works', rejected.html.includes('Application Rejected'));
}

// ===== SECURITY ALERT TEMPLATE =====
section('Security Alert Template');
{
    const tpl = templates.securityAlert('Admin', 'Password changed', '10.0.0.1', 'ru');
    test('Has action description', tpl.html.includes('Password changed'));
    test('Has IP', tpl.html.includes('10.0.0.1'));
    test('Has Comfortaa', tpl.html.includes('Comfortaa'));
}

// ===== MAGIC LINK TEMPLATE (NEW) =====
section('Magic Link Template (NEW)');
{
    const tpl = templates.magicLink('Мария', 'https://tokenpay.space/api/v1/auth/magic-link/confirm?token=abc123', '1.2.3.4', 'Chrome (desktop)', 'ru');
    test('Has magic link URL', tpl.html.includes('magic-link/confirm?token=abc123'));
    test('Has user name', tpl.html.includes('Мария'));
    test('Has IP', tpl.html.includes('1.2.3.4'));
    test('Has device', tpl.html.includes('Chrome (desktop)'));
    test('Has Comfortaa', tpl.html.includes('Comfortaa'));
    test('Has confirm button', tpl.html.includes('Подтвердить вход'));
    test('Has warning text', tpl.html.includes('10 минут'));
    test('No logo stripe', !tpl.html.includes('height:2px;background:rgba(255,255,255'));
    test('Plain text has URL', tpl.text.includes('magic-link/confirm'));

    const tplEn = templates.magicLink('John', 'https://example.com/confirm', '5.6.7.8', 'Firefox (mobile)', 'en');
    test('English magic link works', tplEn.html.includes('Confirm Sign-In'));
    test('English has 10 minutes warning', tplEn.html.includes('10 minutes'));
}

// ===== DEVICE TRUST TEMPLATE (NEW) =====
section('Device Trust Template (NEW)');
{
    const tpl = templates.deviceTrust('Пётр', 'Chrome (desktop)', '192.168.0.1', '2025-03-27 10:30 MSK', 'ru');
    test('Has user name', tpl.html.includes('Пётр'));
    test('Has device', tpl.html.includes('Chrome (desktop)'));
    test('Has IP', tpl.html.includes('192.168.0.1'));
    test('Has time', tpl.html.includes('10:30 MSK'));
    test('Has Comfortaa', tpl.html.includes('Comfortaa'));
    test('Has manage devices button', tpl.html.includes('Управление устройствами'));
    test('Has warning about unauthorized access', tpl.html.includes('смените пароль'));
    test('No logo stripe', !tpl.html.includes('height:2px;background:rgba(255,255,255'));

    const tplEn = templates.deviceTrust('Alice', 'Safari (mobile)', '10.0.0.1', '2025-03-27 10:30 UTC', 'en');
    test('English device trust works', tplEn.html.includes('New Trusted Device'));
    test('English has revoke warning', tplEn.html.includes('revoke access'));
    test('English has Manage Devices button', tplEn.html.includes('Manage Devices'));
}

// ===== CROSS-TEMPLATE CHECKS =====
section('Cross-Template Consistency');
{
    const allTemplates = [
        templates.verificationCode('T', '000000', 10, 'ru'),
        templates.loginNotification('T', '0.0.0.0', 'd', 't', 'ru'),
        templates.welcome('T', 'ru'),
        templates.passwordReset('T', '000000', 10, 'ru'),
        templates.oauthApproval('T', 'A', 's', 'ru'),
        templates.apiKeyCreated('T', 'pk', 'sk', 'n', 'ru'),
        templates.enterpriseApproved('T', 'C', 'ru'),
        templates.enterpriseRejected('T', 'C', '', 'ru'),
        templates.securityAlert('T', 'a', '0', 'ru'),
        templates.magicLink('T', 'https://x.com', '0', 'd', 'ru'),
        templates.deviceTrust('T', 'd', '0', 't', 'ru'),
    ];

    let allHaveComfortaa = true, allHaveGoogleFont = true, noneHaveStripe = true;
    for (const tpl of allTemplates) {
        if (!tpl.html.includes('Comfortaa')) allHaveComfortaa = false;
        if (!tpl.html.includes('fonts.googleapis.com')) allHaveGoogleFont = false;
        if (tpl.html.includes('height:2px;background:rgba(255,255,255')) noneHaveStripe = false;
    }
    test('ALL templates use Comfortaa font-family', allHaveComfortaa, `${allTemplates.length} templates`);
    test('ALL templates import Google Fonts', allHaveGoogleFont);
    test('NO templates have logo stripe', noneHaveStripe);
    test('Total template count = 11', allTemplates.length === 11);
}

// ===== SUMMARY =====
const total = passed + failed;
console.log(`\n\x1b[1m${'='.repeat(40)}\x1b[0m`);
console.log(`\x1b[1mResults: ${passed}/${total} passed${failed ? `, ${failed} FAILED` : ' — ALL PASSED ✅'}\x1b[0m`);
process.exit(failed === 0 ? 0 : 1);
